import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, ScrollView, Modal,
  StyleSheet, SafeAreaView, StatusBar, Pressable
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  Plus, Search, ChevronDown, ChevronUp, Pencil, Trash2, X,
  Phone, IndianRupee, ChevronLeft, ChevronRight, Check
} from 'lucide-react-native';
import { useFonts } from 'expo-font';
import { Fraunces_700Bold, Fraunces_600SemiBold } from '@expo-google-fonts/fraunces';
import { Inter_400Regular, Inter_600SemiBold, Inter_700Bold } from '@expo-google-fonts/inter';
import { NotoSansDevanagari_400Regular } from '@expo-google-fonts/noto-sans-devanagari';

const MONTHS = [
  { key: '01', en: 'Jan' }, { key: '02', en: 'Feb' },
  { key: '03', en: 'Mar' }, { key: '04', en: 'Apr' },
  { key: '05', en: 'May' }, { key: '06', en: 'Jun' },
  { key: '07', en: 'Jul' }, { key: '08', en: 'Aug' },
  { key: '09', en: 'Sep' }, { key: '10', en: 'Oct' },
  { key: '11', en: 'Nov' }, { key: '12', en: 'Dec' },
];

const COLORS = {
  bg: '#F2EDDC', navy: '#1C2B4A', cream: '#FBF8EF', border: '#E4DBC0',
  borderInput: '#D9CFB0', muted: '#8A806A', green: '#2F6B4F',
  greenBg: '#E4F0E8', red: '#A32B2B', redBg: '#FBEAEA',
};

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function currentYM() {
  const d = new Date();
  return { year: d.getFullYear(), month: String(d.getMonth() + 1).padStart(2, '0') };
}

const STORAGE_KEY = '@fees_ledger_students';

export default function App() {
  const [fontsLoaded] = useFonts({
    Fraunces_700Bold, Fraunces_600SemiBold,
    Inter_400Regular, Inter_600SemiBold, Inter_700Bold,
    NotoSansDevanagari_400Regular,
  });

  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const [search, setSearch] = useState('');
  const [expandedId, setExpandedId] = useState(null);
  const [viewYear, setViewYear] = useState(currentYM().year);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);
  const [saving, setSaving] = useState(false);

  const { year: thisYear, month: thisMonth } = currentYM();

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (raw) setStudents(JSON.parse(raw));
      } catch (e) {
        // first run, ignore
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const persist = useCallback(async (next) => {
    setSaving(true);
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      setLoadError(false);
    } catch (e) {
      setLoadError(true);
    } finally {
      setSaving(false);
    }
  }, []);

  const updateStudents = (updater) => {
    setStudents((prev) => {
      const next = typeof updater === 'function' ? updater(prev) : updater;
      persist(next);
      return next;
    });
  };

  const togglePayment = (studentId, ymKey) => {
    updateStudents((prev) =>
      prev.map((s) =>
        s.id === studentId
          ? { ...s, payments: { ...s.payments, [ymKey]: !s.payments[ymKey] } }
          : s
      )
    );
  };

  const saveStudent = (data) => {
    if (data.id) {
      updateStudents((prev) => prev.map((s) => (s.id === data.id ? { ...s, ...data } : s)));
    } else {
      updateStudents((prev) => [...prev, { ...data, id: uid(), payments: {} }]);
    }
    setModalOpen(false);
    setEditingStudent(null);
  };

  const deleteStudent = (id) => {
    updateStudents((prev) => prev.filter((s) => s.id !== id));
    setConfirmDeleteId(null);
    if (expandedId === id) setExpandedId(null);
  };

  const filtered = students.filter((s) => {
    const q = search.trim().toLowerCase();
    if (!q) return true;
    return s.name.toLowerCase().includes(q) || (s.grade || '').toLowerCase().includes(q);
  });

  const thisMonthKey = `${thisYear}-${thisMonth}`;
  const collected = students.filter((s) => s.payments[thisMonthKey]).reduce((sum, s) => sum + Number(s.fee || 0), 0);
  const pending = students.filter((s) => !s.payments[thisMonthKey]).reduce((sum, s) => sum + Number(s.fee || 0), 0);

  const inr = (n) => `\u20B9${Number(n || 0).toLocaleString('en-IN')}`;

  if (!fontsLoaded) return null;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.navy }}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.navy} />
      <View style={{ flex: 1, backgroundColor: COLORS.bg }}>

        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerRule} />
          <View style={styles.headerContent}>
            <Text style={styles.headerSub}>Track every student's payments</Text>
            <Text style={styles.headerTitle}>Fees Ledger</Text>
          </View>
          <View style={styles.summaryStrip}>
            <SummaryCard label="Total Students" value={String(students.length)} />
            <SummaryCard label="Collected" value={inr(collected)} accent={COLORS.green} />
            <SummaryCard label="Pending" value={inr(pending)} accent={COLORS.red} />
          </View>
        </View>

        {/* Search + Add */}
        <View style={styles.searchRow}>
          <View style={styles.searchBox}>
            <Search size={16} color={COLORS.muted} style={{ position: 'absolute', left: 12, top: 12, zIndex: 1 }} />
            <TextInput
              value={search}
              onChangeText={setSearch}
              placeholder="Search by name or class..."
              placeholderTextColor={COLORS.muted}
              style={styles.searchInput}
            />
          </View>
          <TouchableOpacity
            style={styles.addBtn}
            onPress={() => { setEditingStudent(null); setModalOpen(true); }}
          >
            <Plus size={16} color={COLORS.bg} />
            <Text style={styles.addBtnText}>Add</Text>
          </TouchableOpacity>
        </View>

        {loadError && (
          <View style={styles.errorBanner}>
            <Text style={{ color: COLORS.red, fontSize: 13 }}>Save failed. Please try again.</Text>
          </View>
        )}

        {/* Year switcher */}
        <View style={styles.yearRow}>
          <TouchableOpacity onPress={() => setViewYear((y) => y - 1)} style={styles.iconBtn}>
            <ChevronLeft size={14} color={COLORS.navy} />
          </TouchableOpacity>
          <Text style={styles.yearText}>{viewYear}</Text>
          <TouchableOpacity onPress={() => setViewYear((y) => y + 1)} style={styles.iconBtn}>
            <ChevronRight size={14} color={COLORS.navy} />
          </TouchableOpacity>
        </View>

        {/* Student list */}
        <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 32 }}>
          {loading ? (
            <Text style={styles.loadingText}>Loading...</Text>
          ) : filtered.length === 0 ? (
            <EmptyState hasStudents={students.length > 0} />
          ) : (
            <View style={{ gap: 10 }}>
              {filtered.map((s) => (
                <StudentRow
                  key={s.id}
                  student={s}
                  isPaidThisMonth={!!s.payments[thisMonthKey]}
                  expanded={expandedId === s.id}
                  onToggleExpand={() => setExpandedId(expandedId === s.id ? null : s.id)}
                  onTogglePay={() => togglePayment(s.id, thisMonthKey)}
                  onToggleMonth={(mKey) => togglePayment(s.id, `${viewYear}-${mKey}`)}
                  onEdit={() => { setEditingStudent(s); setModalOpen(true); }}
                  onDeleteRequest={() => setConfirmDeleteId(s.id)}
                  viewYear={viewYear}
                  thisYear={thisYear}
                  thisMonth={thisMonth}
                  inr={inr}
                />
              ))}
            </View>
          )}
        </ScrollView>

        {saving && (
          <View style={styles.savingToast}>
            <Text style={{ color: COLORS.bg, fontSize: 12 }}>Saving...</Text>
          </View>
        )}

        <Modal visible={modalOpen} transparent animationType="fade" onRequestClose={() => { setModalOpen(false); setEditingStudent(null); }}>
          <StudentModal
            student={editingStudent}
            onSave={saveStudent}
            onClose={() => { setModalOpen(false); setEditingStudent(null); }}
          />
        </Modal>

        <Modal visible={!!confirmDeleteId} transparent animationType="fade" onRequestClose={() => setConfirmDeleteId(null)}>
          <ConfirmDelete
            studentName={students.find((s) => s.id === confirmDeleteId)?.name}
            onCancel={() => setConfirmDeleteId(null)}
            onConfirm={() => deleteStudent(confirmDeleteId)}
          />
        </Modal>
      </View>
    </SafeAreaView>
  );
}

function SummaryCard({ label, value, accent }) {
  return (
    <View style={styles.summaryCard}>
      <Text style={[styles.summaryValue, accent ? { color: accent } : null]}>{value}</Text>
      <Text style={styles.summaryLabel}>{label}</Text>
    </View>
  );
}

function EmptyState({ hasStudents }) {
  return (
    <View style={{ alignItems: 'center', padding: 48 }}>
      <Text style={styles.emptyTitle}>{hasStudents ? 'No matches found' : 'No students yet'}</Text>
      <Text style={styles.emptySub}>{hasStudents ? 'Try a different search' : 'Tap "Add" to add your first student'}</Text>
    </View>
  );
}

function StudentRow({ student, isPaidThisMonth, expanded, onToggleExpand, onTogglePay, onToggleMonth, onEdit, onDeleteRequest, viewYear, thisYear, thisMonth, inr }) {
  return (
    <View style={styles.rowCard}>
      <View style={styles.rowTop}>
        <Pressable onPress={onToggleExpand} style={{ flex: 1 }}>
          <Text style={styles.rowName} numberOfLines={1}>{student.name}</Text>
          <View style={styles.rowMetaLine}>
            {!!student.grade && <Text style={styles.rowMeta}>{student.grade}</Text>}
            <View style={styles.rowMetaIcon}>
              <IndianRupee size={11} color={COLORS.muted} />
              <Text style={styles.rowMeta}>{Number(student.fee || 0).toLocaleString('en-IN')}/mo</Text>
            </View>
            {!!student.phone && (
              <View style={styles.rowMetaIcon}>
                <Phone size={11} color={COLORS.muted} />
                <Text style={styles.rowMeta}>{student.phone}</Text>
              </View>
            )}
          </View>
        </Pressable>

        <TouchableOpacity
          onPress={onTogglePay}
          style={[styles.payBtn, { backgroundColor: isPaidThisMonth ? COLORS.greenBg : COLORS.redBg }]}
        >
          {isPaidThisMonth ? (
            <>
              <Check size={13} color={COLORS.green} />
              <Text style={[styles.payBtnText, { color: COLORS.green }]}>Paid</Text>
            </>
          ) : (
            <Text style={[styles.payBtnText, { color: COLORS.red }]}>Pending</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity onPress={onToggleExpand} style={styles.chevronBtn}>
          {expanded ? <ChevronUp size={16} color={COLORS.navy} /> : <ChevronDown size={16} color={COLORS.navy} />}
        </TouchableOpacity>
      </View>

      {expanded && (
        <View style={{ padding: 12, paddingTop: 4 }}>
          <View style={styles.monthGrid}>
            {MONTHS.map((m) => {
              const key = `${viewYear}-${m.key}`;
              const paid = !!student.payments[key];
              const isCurrent = viewYear === thisYear && m.key === thisMonth;
              return (
                <TouchableOpacity
                  key={m.key}
                  onPress={() => onToggleMonth(m.key)}
                  style={[
                    styles.monthBtn,
                    { borderColor: isCurrent ? COLORS.navy : COLORS.border, borderWidth: isCurrent ? 1.5 : 1 },
                    { backgroundColor: paid ? COLORS.greenBg : COLORS.bg },
                  ]}
                >
                  <Text style={{ fontSize: 11.5, fontWeight: '600', color: paid ? COLORS.green : COLORS.muted }}>{m.en}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
          <View style={styles.rowActions}>
            <TouchableOpacity onPress={onEdit} style={styles.actionBtn}>
              <Pencil size={13} color={COLORS.navy} />
              <Text style={{ color: COLORS.navy, fontSize: 13 }}>Edit</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={onDeleteRequest} style={styles.actionBtn}>
              <Trash2 size={13} color={COLORS.red} />
              <Text style={{ color: COLORS.red, fontSize: 13 }}>Delete</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );
}

function StudentModal({ student, onSave, onClose }) {
  const [name, setName] = useState(student?.name || '');
  const [grade, setGrade] = useState(student?.grade || '');
  const [fee, setFee] = useState(student?.fee !== undefined ? String(student.fee) : '');
  const [phone, setPhone] = useState(student?.phone || '');
  const [error, setError] = useState('');

  const handleSave = () => {
    if (!name.trim()) { setError('Name is required'); return; }
    if (fee === '' || isNaN(Number(fee)) || Number(fee) < 0) { setError('Enter a valid fee amount'); return; }
    onSave({ id: student?.id, name: name.trim(), grade: grade.trim(), fee: Number(fee), phone: phone.trim() });
  };

  return (
    <Pressable style={styles.overlayBottom} onPress={onClose}>
      <Pressable style={styles.sheet} onPress={(e) => e.stopPropagation && e.stopPropagation()}>
        <View style={styles.sheetHeader}>
          <Text style={styles.sheetTitle}>{student ? 'Edit Student' : 'Add New Student'}</Text>
          <TouchableOpacity onPress={onClose}><X size={20} color={COLORS.muted} /></TouchableOpacity>
        </View>

        <Field label="Name">
          <TextInput value={name} onChangeText={setName} placeholder="e.g. Rahul Kumar" placeholderTextColor={COLORS.muted} style={styles.input} autoFocus />
        </Field>
        <Field label="Class">
          <TextInput value={grade} onChangeText={setGrade} placeholder="e.g. Class 2" placeholderTextColor={COLORS.muted} style={styles.input} />
        </Field>
        <Field label="Monthly Fee (₹)">
          <TextInput value={fee} onChangeText={setFee} placeholder="e.g. 500" placeholderTextColor={COLORS.muted} keyboardType="numeric" style={styles.input} />
        </Field>
        <Field label="Phone (optional)">
          <TextInput value={phone} onChangeText={setPhone} placeholder="e.g. 98765xxxxx" placeholderTextColor={COLORS.muted} keyboardType="phone-pad" style={styles.input} />
        </Field>

        {!!error && <Text style={{ color: COLORS.red, fontSize: 13, marginBottom: 8 }}>{error}</Text>}

        <TouchableOpacity onPress={handleSave} style={styles.saveBtn}>
          <Text style={styles.saveBtnText}>Save</Text>
        </TouchableOpacity>
      </Pressable>
    </Pressable>
  );
}

function Field({ label, children }) {
  return (
    <View style={{ marginBottom: 12 }}>
      <Text style={styles.fieldLabel}>{label}</Text>
      {children}
    </View>
  );
}

function ConfirmDelete({ studentName, onCancel, onConfirm }) {
  return (
    <Pressable style={styles.overlayCenter} onPress={onCancel}>
      <Pressable style={styles.confirmBox} onPress={(e) => e.stopPropagation && e.stopPropagation()}>
        <Text style={styles.confirmTitle}>Delete {studentName}?</Text>
        <Text style={styles.confirmSub}>Their entire fee record will be deleted too. This cannot be undone.</Text>
        <View style={{ flexDirection: 'row', gap: 8, justifyContent: 'flex-end' }}>
          <TouchableOpacity onPress={onCancel} style={styles.cancelBtn}>
            <Text style={{ color: COLORS.navy, fontSize: 13.5 }}>Cancel</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={onConfirm} style={styles.deleteBtn}>
            <Text style={{ color: COLORS.cream, fontSize: 13.5, fontWeight: '600' }}>Delete</Text>
          </TouchableOpacity>
        </View>
      </Pressable>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  header: { backgroundColor: COLORS.navy, paddingBottom: 22 },
  headerRule: { position: 'absolute', left: 28, top: 0, bottom: 0, width: 2, backgroundColor: COLORS.red, opacity: 0.5 },
  headerContent: { padding: 22, paddingLeft: 44, paddingBottom: 14 },
  headerSub: { fontSize: 13, color: '#C9BFA0', marginBottom: 2 },
  headerTitle: { fontFamily: 'Fraunces_700Bold', fontSize: 28, color: COLORS.bg },
  summaryStrip: { flexDirection: 'row', gap: 8, paddingHorizontal: 20, marginLeft: 24 },
  summaryCard: { flex: 1, backgroundColor: COLORS.bg, borderRadius: 10, borderBottomLeftRadius: 0, borderBottomRightRadius: 0, padding: 10, paddingBottom: 12 },
  summaryValue: { fontFamily: 'Fraunces_700Bold', fontSize: 18, color: COLORS.navy },
  summaryLabel: { fontSize: 10.5, color: COLORS.muted, marginTop: 2 },
  searchRow: { flexDirection: 'row', gap: 8, padding: 16, paddingBottom: 8 },
  searchBox: { flex: 1, position: 'relative', justifyContent: 'center' },
  searchInput: { paddingVertical: 10, paddingLeft: 36, paddingRight: 12, borderRadius: 8, borderWidth: 1, borderColor: COLORS.borderInput, backgroundColor: COLORS.cream, fontSize: 14, color: COLORS.navy },
  addBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: COLORS.navy, borderRadius: 8, paddingHorizontal: 16, justifyContent: 'center' },
  addBtnText: { color: COLORS.bg, fontSize: 14, fontWeight: '600' },
  errorBanner: { margin: 16, marginBottom: 8, marginTop: 0, padding: 10, backgroundColor: COLORS.redBg, borderRadius: 8 },
  yearRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 12, paddingVertical: 8 },
  yearText: { fontFamily: 'Fraunces_600SemiBold', color: COLORS.navy, fontSize: 15 },
  iconBtn: { borderWidth: 1, borderColor: COLORS.borderInput, backgroundColor: COLORS.cream, borderRadius: 6, width: 26, height: 26, alignItems: 'center', justifyContent: 'center' },
  loadingText: { textAlign: 'center', color: COLORS.muted, padding: 40, fontSize: 14 },
  emptyTitle: { fontFamily: 'Fraunces_600SemiBold', fontSize: 17, color: COLORS.navy, marginBottom: 6 },
  emptySub: { fontSize: 13, color: COLORS.muted },
  rowCard: { backgroundColor: COLORS.cream, borderRadius: 12, borderWidth: 1, borderColor: COLORS.border, overflow: 'hidden' },
  rowTop: { flexDirection: 'row', alignItems: 'center', padding: 12, gap: 10 },
  rowName: { fontSize: 15, fontWeight: '600', color: COLORS.navy },
  rowMetaLine: { flexDirection: 'row', gap: 8, alignItems: 'center', marginTop: 2, flexWrap: 'wrap' },
  rowMeta: { fontSize: 12.5, color: COLORS.muted },
  rowMetaIcon: { flexDirection: 'row', alignItems: 'center', gap: 2 },
  payBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, borderRadius: 20, paddingVertical: 6, paddingHorizontal: 12 },
  payBtnText: { fontSize: 12.5, fontWeight: '700' },
  chevronBtn: { padding: 4 },
  monthGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 10 },
  monthBtn: { width: '22.5%', borderRadius: 8, paddingVertical: 7, alignItems: 'center' },
  rowActions: { flexDirection: 'row', gap: 14, justifyContent: 'flex-end' },
  actionBtn: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  savingToast: { position: 'absolute', bottom: 16, right: 16, backgroundColor: COLORS.navy, paddingVertical: 6, paddingHorizontal: 10, borderRadius: 6, opacity: 0.9 },
  overlayBottom: { flex: 1, backgroundColor: 'rgba(28,43,74,0.45)', justifyContent: 'flex-end' },
  sheet: { backgroundColor: COLORS.cream, borderTopLeftRadius: 18, borderTopRightRadius: 18, padding: 20 },
  sheetHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  sheetTitle: { fontFamily: 'Fraunces_600SemiBold', fontSize: 19, color: COLORS.navy },
  fieldLabel: { fontSize: 12.5, color: COLORS.muted, marginBottom: 5 },
  input: { paddingVertical: 11, paddingHorizontal: 12, borderRadius: 9, borderWidth: 1, borderColor: COLORS.borderInput, fontSize: 14.5, color: COLORS.navy, backgroundColor: '#FFFFFF' },
  saveBtn: { backgroundColor: COLORS.navy, borderRadius: 10, paddingVertical: 13, alignItems: 'center', marginTop: 6 },
  saveBtnText: { color: COLORS.bg, fontSize: 15, fontWeight: '600' },
  overlayCenter: { flex: 1, backgroundColor: 'rgba(28,43,74,0.45)', alignItems: 'center', justifyContent: 'center', padding: 24 },
  confirmBox: { backgroundColor: COLORS.cream, borderRadius: 14, padding: 20, maxWidth: 320, width: '100%' },
  confirmTitle: { fontFamily: 'Fraunces_600SemiBold', fontSize: 16, color: COLORS.navy, marginBottom: 6 },
  confirmSub: { fontSize: 13, color: COLORS.muted, marginBottom: 16 },
  cancelBtn: { paddingVertical: 8, paddingHorizontal: 14, borderRadius: 8, borderWidth: 1, borderColor: COLORS.borderInput },
  deleteBtn: { paddingVertical: 8, paddingHorizontal: 14, borderRadius: 8, backgroundColor: COLORS.red },
});
