# Fees Ledger — React Native App

Ye tumhara web artifact hai jo React Native (Expo) me convert ho chuka hai.
Same design, same features — bas ab ye real mobile app hai jo Play Store pe ja sakti hai.

## Step 1: Apne computer par setup

1. [Node.js](https://nodejs.org) install karo (agar nahi hai)
2. Terminal me:
   ```
   npm install -g eas-cli
   cd FeesLedgerApp
   npm install
   ```

## Step 2: Test karo (phone par live preview)

1. Apne phone me "Expo Go" app install karo (Play Store se)
2. Terminal me: `npx expo start`
3. QR code scan karo Expo Go app se — turant apna app dikhega

## Step 3: Free Expo account banao

1. https://expo.dev pe free account banao
2. Terminal me: `eas login`

## Step 4: Play Store ke liye APK/AAB build karo

Testing ke liye (APK — seedha install kar sakte ho):
```
eas build --platform android --profile preview
```

Play Store submission ke liye (AAB file):
```
eas build --platform android --profile production
```

Pehli baar `eas build` chalane par ek `eas.json` file khud ban jaayegi — usse accept kar lena.
Build 10-20 minute me cloud par ho jaata hai, phir download link milega.

## Step 5: Play Store par daalo

1. https://play.google.com/console pe developer account banao (one-time $25 fee)
2. Naya app banao, AAB file upload karo
3. Store listing (screenshots, description, icon) bharo
4. Submit for review — usually 1-3 din me live ho jaata hai

## Zaroori: App icon aur splash screen

`assets/` folder me apna icon aur splash image daal do:
- `icon.png` — 1024x1024
- `adaptive-icon.png` — 1024x1024
- `splash.png` — 1284x2778 (ya koi bhi tall image)

Agar nahi daaloge toh default Expo icon use hoga — build ke liye zaroori nahi, but Play Store pe achha nahi lagega.

## Notes

- Data phone ke local storage me save hota hai (AsyncStorage) — internet ki zaroorat nahi
- Agar future me students ka data cloud pe backup karna ho (naya phone lene par bhi data mile), tab bata dena — Firebase ya Supabase add kar sakte hain
